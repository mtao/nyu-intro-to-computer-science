import java.util.ArrayList;
import java.util.Scanner;
interface Matcher {
    public boolean match(String path);
}
class PrefixMatcher implements Matcher {
    private String prefix;
    public PrefixMatcher(String prefix) {
        this.prefix = prefix;
    }

    public boolean match(String path) {
        return path.startsWith(prefix);
    }
}

class ExtensionMatcher implements Matcher {
    private String extension;
    public ExtensionMatcher(String extension) {
        this.extension = extension;
    }

    public boolean match(String path) {
        // note this excape character thing wouldnt be expected
        String[] tokens = path.split("\\.");
        if (tokens.length < 2) {
            return false;
        }
        return tokens[tokens.length - 1].equals(extension);
    }
}
public class MatcherFactory {
    static private int numMatchers = 0;

    static public int getNummMatchers() {
        return numMatchers;
    }

    Matcher create(String type, String argument) {
        numMatchers++;

        switch (type) {
            case "prefix":
                return new PrefixMatcher(argument);
            case "extension":
                return new ExtensionMatcher(argument);
            default:
                return null;
        }
    }

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

        MatcherFactory factory = new MatcherFactory();
        ArrayList<Matcher> matchers = new ArrayList<Matcher>();

        while (true) {
            String line = scn.nextLine();
            String[] tokens = line.split(" ");
            if (tokens.length < 1) {
                continue;
            }
            switch (tokens[0]) {
                case "prefix":
                case "extension":
                    matchers.add(factory.create(tokens[0], tokens[1]));
                    break;

                case "run":
                    for (int j = 1; j < tokens.length; ++j) {
                        String token = tokens[j];
                        System.out.print("Matching " + token + ": ");
                        for (Matcher m : matchers) {
                            System.out.print(m.match(token) + ",");
                        }
                        System.out.println();
                    }
                    return;
            }
        }
    }
}
