package mtao_prac;

public class Transaction {
    private String source;
    private String destination;
    private String category;
    private double amount;

    public Transaction(
            String source,
            String destination,
            String category,
            double amount) {
        this.source = source;
        this.destination = destination;
        this.category = category;
        this.amount = amount;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getCategory() {
        return category;
    }

    public double getAmount() {
        return amount;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
