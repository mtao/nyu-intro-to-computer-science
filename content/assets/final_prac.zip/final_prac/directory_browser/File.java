package mtao_prac.directory_browser;

public abstract class File extends FilesystemEntry {
    private int size;

    public int getSize() {
        return size;
    }

    public String toString() {
        return super.toString() + "   " + size + " b";
    }
}
