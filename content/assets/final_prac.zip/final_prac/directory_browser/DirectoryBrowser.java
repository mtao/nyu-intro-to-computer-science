package mtao_prac.directory_browser;

import java.io.FileNotFoundException;
import java.util.Arrays;

public class DirectoryBrowser {
    private Directory workingDirectory;

    public FilesystemEntry getEntry(Directory d, String name) throws FileNotFoundException {
        for (FilesystemEntry e : d.getEntries()) {
            if (e.getName().equals(name)) {
                return e;
            }
        }
        throw new FileNotFoundException();
    }

    public void setDirectory(String path) throws FileNotFoundException {
        String[] directories = path.split("/");

        Directory d = new Directory();
        if (directories[0].equals("")) {
            d = Directory.getRoot();
        } else {
            d = workingDirectory;
        }

        for (int i = 0; i < directories.length; i++) {
            if (directories[0].equals("")) {
                continue;
            }

            FilesystemEntry fe = getEntry(d, directories[i]);
            if (fe instanceof Directory) {
                d = (Directory) fe;
            } else {
                throw new FileNotFoundException();
            }
        }

        workingDirectory = d;
    }

    public DirectoryBrowser(String absolutePath) throws FileNotFoundException {
        setDirectory(absolutePath);
    }

    public DirectoryBrowser() {
        workingDirectory = Directory.getRoot();
    }

    public void listContents() {
        for (FilesystemEntry e : workingDirectory.getEntries()) {
            System.out.println(e);
        }
    }

    public int localFileSize() {
        int size = 0;
        for (FilesystemEntry e : workingDirectory.getEntries()) {
            if (e instanceof File) {
                size += ((File) e).getSize();
            }
        }

        return size;
    }

}
