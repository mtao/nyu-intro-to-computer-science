package mtao_prac.directory_browser;

public abstract class FilesystemEntry {
    private String path;
    private String name;

    public FilesystemEntry(String path, String name) {
        this.path = path;
        this.name = name;
    }

    public FilesystemEntry() {
    }

    public String getPath() {
        return path;
    }

    public String getName() {
        return name;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void getName(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }
}
