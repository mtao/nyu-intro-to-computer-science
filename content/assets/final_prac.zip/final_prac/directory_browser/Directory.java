package mtao_prac.directory_browser;

public class Directory extends FilesystemEntry {
    private FilesystemEntry[] entries;

    public Directory(String path, String name) {
        super(path, name);
    }

    public Directory() {
    }

    public static Directory getRoot() {
        return new Directory("/", "");
    }

    public FilesystemEntry[] getEntries() {
        return entries;
    }
}
