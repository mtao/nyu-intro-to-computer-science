package mtao_prac;

import java.util.ArrayList;

public class Ledger implements LedgerInterface {
    ArrayList<Transaction> transactions;

    public Ledger() {
        transactions = new ArrayList<Transaction>();
    }

    public double getMaxSpent() {
        double max = 0;

        for (Transaction t : transactions) {
            max = Math.max(max, t.getAmount());
        }

        return max;
    }

    public double getTotalTransferredByCategory(String category) {
        double total = 0;

        for (Transaction t : transactions) {
            if (t.getCategory().equals(category)) {
                total += t.getAmount();
            }
        }

        return total;
    }

    public int getTransactionCount(String user) {
        int total = 0;

        for (Transaction t : transactions) {
            if (t.getSource().equals(user) ||
                    t.getDestination().equals(user)) {
                total++;
            }
        }

        return total;
    }

    public void add(Transaction t) {
        transactions.add(t);
    }
}
