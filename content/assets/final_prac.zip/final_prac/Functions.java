package mtao_prac;

import java.util.Arrays;
import java.util.Random;

public class Functions {
    public static double minimalSquare(double a, double b) {
        double x = (a > b) ? a : b;
        return x * x;
    }

    public static double geometricMean(double[] a) {
        // double x = 1;
        // for (double e : a) {
        // x *= e;
        // }
        double x = a[0];
        for (int i = 1; i < a.length; i++) {
            x *= a[i];
        }

        return Math.pow(x, 1.0 / a.length);
    }

    public static Random rnd = new Random();

    public static int sample() {
        System.out.println("call sample");
        return rnd.nextInt(10);
    }

    public static int reportSample() {
        int n = 0;

        do {
            n++;
        } while (sample() != 5);

        return n;

    }

    public static double avgWater(double[][] vals) {
        double sum = 0;
        int n = 0;

        for (int i = 0; i < vals.length; i++) {
            n += vals[i].length;
            for (int j = 0; j < vals[i].length; j++) {
                sum += vals[i][j];
            }
        }

        return sum / n;
    }

    public static boolean isOnHalfplane(double a, double b, double c, double x, double y) {
        return a * x + b * y + c > 0;
    }

    public static int numOfDivisors(int b) {
        int counter = 0;

        for (int i = 1; i <= b; i++) {
            if (b % i == 0) {
                ++counter;
            }
        }

        return counter;
    }

    public void useOfPunctuation(String str) {
        int countExclamation = 0;
        int countQuestion = 0;

        for (char c : str.toCharArray()) {
            switch (c) {
                case '!':
                    countExclamation++;
                    break;
                case '?':
                    countQuestion++;
                    break;
            }
        }

        System.out.println("!: " + countExclamation);
        System.out.println("?: " + countQuestion);

    }

    public static int[] mergeArrays(int[] a, int[] b) {
        int[] c = new int[a.length + b.length];
        int iA = 0;
        int iB = 0;
        int iC = 0;
        while (iA < a.length && iB < b.length) {
            if (a[iA] < b[iB]) {
                c[iC++] = a[iA++];
            } else {
                c[iC++] = b[iB++];
            }
        }
        for (int i = iA; i < a.length; i++) {
            c[iC++] = a[i];
        }
        for (int i = iB; i < b.length; i++) {
            c[iC++] = b[i];
        }

        return c;
    }

    public static void main(String[] args) {
        // System.out.println(minimalSquare(2, 3));
        // System.out.println(minimalSquare(4, 3));
        // System.out.println(geometricMean(new double[] { 3, 27 }));
        // System.out.println(reportSample());
        // System.out.println(avgWater(new double[][] { {}, {} }));
        // System.out.println(numOfDivisors(12));

        int[] a = { 1, 2, 5, 7 };
        int[] b = { 3, 4, 7 };
        System.out.println(Arrays.toString(mergeArrays(a, b)));
    }
}
