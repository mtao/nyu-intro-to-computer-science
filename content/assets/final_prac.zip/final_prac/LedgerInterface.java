package mtao_prac;

public interface LedgerInterface {

    // computes the most money spent in a single transaction
    double getMaxSpent();

    // computes the total amount of money transferred in a single category
    double getTotalTransferredByCategory(String category);

    // outputs the total number of transactions where the user is
    // a source ordestination
    int getTransactionCount(String user);

    // add a single transaction to the ledger
    void add(Transaction t);

}
