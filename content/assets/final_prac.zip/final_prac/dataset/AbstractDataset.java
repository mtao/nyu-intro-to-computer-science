package mtao_prac.dataset;

public interface AbstractDataset {

    public int size();

    public double get(int index);

    public void append(double value);

    public double getAverage();

    public double getMedian();

    public double[] getMinMax();

    public double getRange();
}
