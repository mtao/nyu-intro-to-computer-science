package mtao_prac.dataset;

import java.util.ArrayList;
import java.util.Collections;

public class Dataset implements AbstractDataset {
    ArrayList<Double> data;

    public int size() {
        return data.size();
    }

    public double get(int index) {
        return data.get(index);
    }

    public void append(double value) {
        data.add(value);
    }

    public double getAverage() {
        double avg = 0;
        for (Double d : data) {
            avg += d;
        }

        return avg / size();
    }

    public double getMedian() {
        ArrayList<Double> sortedData = (ArrayList<Double>) data.clone();
        Collections.sort(sortedData);

        return sortedData.get(size() / 2);
    }

}
