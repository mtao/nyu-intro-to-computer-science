package mtao_prac.cipher;

public interface CharacterCipher {
    char encode(char c);

    char decode(char c);
}
