package mtao_prac.cipher;

public interface VectorCipherInterface {
    public char[] encode(char[] input);

    public char[] decode(char[] encoded);
}
