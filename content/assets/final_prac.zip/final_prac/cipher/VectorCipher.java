package mtao_prac.cipher;

public class VectorCipher implements VectorCipherInterface {
    private CharacterCipher cipher;

    public VectorCipher(CharacterCipher cipher) {
        this.cipher = cipher;
    }

    public char[] encode(char[] input) {
        char[] output = new char[input.length];

        for (int i = 0; i < input.length; i++) {
            output[i] = cipher.encode(input[i]);
        }

        return output;
    }

    public char[] decode(char[] encoded) {
        char[] output = new char[encoded.length];

        int i = 0;
        while (i < encoded.length) {
            output[i] = cipher.decode(encoded[i]);
            i++;
        }

        return output;
    }

}
