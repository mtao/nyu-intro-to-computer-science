package mtao_prac.cipher;

public class App {
    public static String encodeWord(String str, int offset) {
        CaesarCipher caesar = new CaesarCipher(offset);
        VectorCipher vc = new VectorCipher(caesar);
        char[] encoded = vc.encode(str.toCharArray());
        return new String(encoded);
    }

    public static String decodeWord(String str, int offset) {
        CaesarCipher caesar = new CaesarCipher(offset);
        VectorCipher vc = new VectorCipher(caesar);
        char[] decoded = vc.decode(str.toCharArray());
        return new String(decoded);
    }

    public static void main(String[] args) {
        String hw = "Hello World";

        System.out.println(hw);
        String enc = encodeWord(hw, 1000);
        System.out.println(enc);
        System.out.println(decodeWord(enc, 1000));
    }
}
