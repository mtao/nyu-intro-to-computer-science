package mtao_prac.cipher;

public class CaesarCipher implements CharacterCipher {
    private int offset;

    public CaesarCipher(int offset) {
        this.offset = offset;
    }

    public char encode(char c) {
        if (c == ' ') {
            return c;
        }
        return (char) ((int) c + offset);
    }

    public char decode(char c) {
        if (c == ' ') {
            return c;
        }
        return (char) ((int) c - offset);
    }
}
