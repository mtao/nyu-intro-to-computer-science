import processing.core.PApplet;
import circledrawing.*;
import java.util.ArrayList;
public class App extends PApplet {


    ArrayList<Circle> circles;

    Circle cursor;
    public void settings() {
        this.setSize(1024,1024);
    }

    public void keyPressed() {
        switch(this.key) {
            case '1':
            cursor.updateFillColor('r',-5);
            // decrease r
            break;
            case '2':
            // increase r
            cursor.updateFillColor('r',5);
                        break;
            case '3':
            cursor.updateFillColor('g',-5);
            // decrease g
            break;
            case '4':
            // increase g
            cursor.updateFillColor('g',5);
            break;
            case '5':
            cursor.updateFillColor('b',-5);
            // decrease b
            break;
            case '6':
            // increase b
            cursor.updateFillColor('b',5);
            break;
        }
    }

    public void setup() {
        cursor = new Circle(512,512,100);
        circles = new ArrayList<Circle>();
    }

    public Point mousePosition() {
        return new Point(this.mouseX,this.mouseY);
    }

    void updateMouseCenter() {
        cursor.setCenter(mousePosition());
    }

    public void mousePressed() {
        circles.add(cursor.clone());
       
    }
    public void mouseMoved() {
        updateMouseCenter();
    }
    public void mouseDragged() {
        updateMouseCenter();
    }

    public void draw() {
        this.background(255,255,0);

        cursor.draw(this);

        for(Circle c: circles) {
            c.draw(this);
        } 
    }
    public static void main(String[] args) {
        PApplet.main("App");

    }
}
