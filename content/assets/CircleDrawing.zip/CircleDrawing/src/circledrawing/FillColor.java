package circledrawing;
import processing.core.PApplet;

public class FillColor extends Color {

    public FillColor clone() {
        return new FillColor(this);
    }

    public FillColor(Color c) {
        super(c);
    }

    public FillColor(FillColor c) {
        super(c);
    }

    public FillColor(int r, int g, int b) {
        super(r,g,b);
    }
    public void apply(PApplet app) {

        if(this.getActive()) {
            app.fill(r,g,b);
        } else {
            app.noFill();
        }
    }

}
