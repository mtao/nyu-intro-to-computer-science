package circledrawing;
import processing.core.PApplet;
public class Circle {

    Point center;

    FillColor fillColor;
    StrokeColor strokeColor;
    int radius;
    
    public void updateFillColor(char color, int update) {
        this.fillColor.updateColor(color,update);
    }

    

    public Circle clone() {
        Circle r = new Circle(center.getX(),center.getY(), this.radius);
        r.fillColor = this.fillColor.clone();
        r.strokeColor = this.strokeColor.clone();
        return r;
    }

    public Circle(int x,int y,int radius) {
        this.center = new Point(x,y);
        this.fillColor = new FillColor(0,255,0);
        this.strokeColor = new StrokeColor(0,0,0);

        this.radius = radius;
    }

    public void draw(PApplet app) {
        fillColor.apply(app);
        strokeColor.apply(app);
        app.circle(this.center.getX(),this.center.getY(),this.radius);

    }

    public void setCenter(Point p) {
        this.center.setXY(p.getX(), p.getY());
    }
}
