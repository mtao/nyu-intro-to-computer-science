package circledrawing;

import processing.core.PApplet;

public class Color {
    int r;
    int g;
    int b;

    public void updateColor(char color, int update) {
        switch(color) {
            case 'r': r+=update; break;
            case 'g': g+=update; break;
            case 'b': b+=update; break;
            default: break;
        }

        System.out.printf("%d %d %d\n", r,g,b);
    }

    boolean active = true;

    public boolean getActive() {
        return this.active;
    }
    public void apply(PApplet app) {}

 
    public Color clone() {
        Color c = new Color(r,g,b);
        c.active = this.active;
        return c;
    }

    public Color(Color c) {
        this.r = c.r;
        this.g = c.g;
        this.b = c.b;
    }

    public Color(int r, int g, int b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public void setRGB(int r, int g, int b) {
        this.r = r;
        this.b = b;
        this.g = g;
    }
}
