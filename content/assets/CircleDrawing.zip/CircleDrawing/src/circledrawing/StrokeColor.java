package circledrawing;
import processing.core.PApplet;

public class StrokeColor extends Color {
    
    float weight = 5;


    public StrokeColor clone() {
        return new StrokeColor(this);
    }
    public StrokeColor(Color c) {
        super(c);
    }
    public StrokeColor(Color c, int weight) {
        super(c);
        this.weight = weight;
    }
    public StrokeColor(StrokeColor c) {
        super(c);
        this.weight = c.weight;
    }

    public StrokeColor(int r, int g, int b) {
        super(r,g,b);
        this.weight = 20;
    }
    public StrokeColor(int r, int g, int b, int weight) {
        super(r,g,b);
        this.weight = weight;
    }
    public void apply(PApplet app) {
        if(this.getActive()) {
            app.strokeWeight(this.weight);
            app.stroke(this.r,this.g,this.b);
        } else {
            app.noStroke();
        }

    }
   
}
