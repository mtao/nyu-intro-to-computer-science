
class Package {
    private int ID;
    private String location;
    private String destination;

    private static int unusedID = 0;

    public Package() {
        ID = unusedID++;
    }

    public Package(int ID, String location, String destination) {
        this.ID = ID;
        this.location = location;
        this.destination = destination;
    }
    public Package(String location, String destination) {
        this.location = location;
        this.destination = destination;
        this.ID = unusedID++;
    }

    public Package(int ID, String destination) {
        this.ID = ID;
        this.destination = destination;
        this.location = "unknown";
    }

    public int getID() {
        return ID;
    }
    public String getDestination() {
        return this.destination;
    }
    public String getLocation() {
        return this.location;
    }
    public void setLocation(String loc) {
        this.location = loc;
    }

    public boolean isLost() {
        return this.location.equals("unknown");
    }
}

class PackageFactory {
    private int unusedID = 0;

    Package create(String location, String destination) {
        Package newPackage = new Package(unusedID++, location, destination);
        return newPackage;
    }
}

public class Packages {}
