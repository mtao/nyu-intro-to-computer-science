
class Point {
    public int x,y;
    Point(int x, int y) { this.x = x; this.y = y;}
}

class Polygon {
    public Point[] points;
    public Point[] getPoints() {
        return points;
    }
}

public class BoundingBox {
    
    private Point min;
    private Point max;

    private static int MIN_VALUE = -10000;
    private static int MAX_VALUE = 10000;


    public BoundingBox() {
        this.min = new Point(MAX_VALUE,MAX_VALUE);
        this.max = new Point(MIN_VALUE, MIN_VALUE);
    }

    public void expand(Point p) {
        min.x = Math.min(min.x,p.x);
        min.y = Math.min(min.y,p.y);
        max.x = Math.max(max.x,p.x);
        max.y = Math.max(max.y,p.y);
    }
    public void expand(Polygon poly) {
        for(Point p: poly.getPoints()) {
            expand(p);
        }
    }
    public boolean isEmpty() {
        // use > instead of >= to allow for a single point not be empty
        return min.x > max.x || min.y > max.y;
    }

    public BoundingBox intersection(BoundingBox other) {
        BoundingBox isect = new BoundingBox();
        // note that privateness doesn't prevent "this" boundingbox
        // from the ability to affect private members of "isect"
        isect.min.x = Math.max(min.x,other.min.x);
        isect.min.y = Math.max(min.y,other.min.y);
        isect.max.x = Math.min(max.x,other.max.x);
        isect.max.y = Math.min(max.y,other.max.y);
        return isect;
    }


    public boolean doesIntersect(BoundingBox other) {
        return intersection(other).isEmpty();
    }

}
