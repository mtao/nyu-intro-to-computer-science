
import java.util.Random;

class Fowl {
}

class Duck extends Fowl {

}

class Goose extends Fowl {

}



public class DuckDuckGoose {
    
    public Fowl[] getFowls(int N) {

        Fowl[] fowls = new Fowl[N];

        Random r = new Random();
        // 1 in 5 have to be a goose
        for(int j = 0; j < N; ++j) {
            boolean makeGoose = r.nextInt(5) == 0;
            Fowl newFowl;
            if(makeGoose) {
                newFowl = new Goose();
            } else {
                newFowl = new Duck();
            }
            fowls[j] = newFowl;
        }

        return fowls;
    }

    public Goose[] getGeese(Fowl[] fowls) {

        int gooseCount = 0;

        for(Fowl fowl: fowls) {
            if(fowl instanceof Goose) {
                gooseCount++;
            }
        }

        Goose[] geese = new Goose[gooseCount];
        
        int gooseIndex = 0;
        for(Fowl fowl: fowls) {
            if(fowl instanceof Goose) {
                geese[gooseIndex++] = (Goose)fowl;
            }
        }
        return geese;
    } 
}
