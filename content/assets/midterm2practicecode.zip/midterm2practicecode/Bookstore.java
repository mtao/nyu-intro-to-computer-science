import java.util.ArrayList;

class Book {
    private String title;
    private String author;
    private double price;
    private int numPages;

    public Book(String title, String author, double price, int numPages) {
        this.title = title;
        this.author = author;
        this.price = price;
        this.numPages = numPages;
    }
    public Book(String title, String author, int numPages) {
        this.title = title;
        this.author = author;
        this.setPrice(9.99);
        this.numPages = numPages;
    }

    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public double getPrice() {
        return price;
    }
    public int getNumPAges() {
        return numPages;
    }
    void setPrice(double price) {
        this.price = price;
    }
}

class BorrowableBook extends Book {
    private int dueDate;

    public BorrowableBook(String title, String author, int numPages, int dueDate) {
        super(title, author, 0.0, numPages);
        this.setDueDate(dueDate);
    }

    public int getDueDate() {
        return dueDate;
    }
    public void setDueDate(int dueDate) {
        this.dueDate = dueDate;
    }

    public boolean isLate(int currentDate) {
        return dueDate < currentDate;
    }
}

class Inventory {
    private double cashAvailable = 0;
    private ArrayList<Book> books;

    public Inventory() {
        this.cashAvailable = 0;
        books = new ArrayList<>();
    }

    public void addBook(Book b) {
        books.add(b);
    }

    public void buyBook(Book b) {
        cashAvailable -= b.getPrice();
        addBook(b);
    }

    public Book sellBook(String name, int currentDate) {
        for (Book b : books) {
            if (name.equals(b.getTitle())) {
                if (b instanceof BorrowableBook) {
                    // set due date to 2 weeks in the future (wasn't in the problem definition)
                    BorrowableBook bb = (BorrowableBook) b;
                    bb.setDueDate(currentDate + 14);
                    books.remove(b);
                    return b;
                } else {
                    books.remove(b);
                    return b;
                }
            }
        }
        return null;
    }
}

public class Bookstore {}
