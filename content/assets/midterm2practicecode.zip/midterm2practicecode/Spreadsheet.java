class Cell {}

class NumericCell extends Cell {
    public NumericCell(double v) {
        setValue(v);
    }
    void setValue(double v) {
        value = v;
    }
    double getValue() {
        return value;
    }
    private double value;
}

class LogicalCell extends Cell {
    public LogicalCell(boolean v) {
        setValue(v);
    }
    void setValue(boolean v) {
        value = v;
    }
    boolean getValue() {
        return value;
    }
    private boolean value;
}

class StringCell extends Cell {
    public StringCell(String v) {
        setValue(v);
    }
    void setValue(String v) {
        value = v;
    }
    String getValue() {
        return value;
    }
    private String value;
}

public class Spreadsheet {
    private Cell[][] data;
    public Spreadsheet(int rows, int cols) {
        data = new Cell[rows][cols];
    }

    void addNumericCell(int x, int y, double v) {
        data[x][y] = new NumericCell(v);
    }
    void addLogicalCell(int x, int y, boolean v) {
        data[x][y] = new LogicalCell(v);
    }
    void addStringCell(int x, int y, String v) {
        data[x][y] = new StringCell(v);
    }

    private boolean looksLikeNumber(String value) {
        try {
            Double.parseDouble(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    private boolean looksLikeLogical(String value) {
        return value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false");
    }
    // 4.6
    void addValue(int x, int y, String value) {
        if (looksLikeNumber(value)) { // true
            addNumericCell(x, y, Double.parseDouble(value));
        } else if (looksLikeLogical(value)) {
            addLogicalCell(x, y, Boolean.parseBoolean(value));
        } else {
            addStringCell(x, y, value);
        }
    }

    void add(int ax, int ay, int bx, int by, int cx, int cy) {
        // data[cx][cy] = data[ax][ay] + data[bx][by]

        Cell a = data[ax][ay];
        Cell b = data[bx][by];

        Cell c;
        if (a instanceof NumericCell && b instanceof NumericCell) {
            NumericCell an = (NumericCell) a;
            NumericCell bn = (NumericCell) b;
            double sum = an.getValue() + bn.getValue();
            c = new NumericCell(sum);
        } else if (a instanceof LogicalCell && b instanceof LogicalCell) {
            LogicalCell al = (LogicalCell) a;
            LogicalCell bl = (LogicalCell) b;
            boolean sum = al.getValue() || bl.getValue();

            c = new LogicalCell(sum);

            // summation ~ logical or
            // (a,b) = (true,true) ~ (1,1) 1+1 = 2 ~ true
            // (a,b) = (true,false) ~ (1,0) 1+0 = 1 ~ true
            // (a,b) = (false,true) ~ (0,1) 0+1 = 1 ~ true
            // (a,b) = (false,false) ~ (0,0) 0+0 = 0 ~ false

            // multiplication ~ logical and
            // (a,b) = (true,true) ~ (1,1) 1*1 = 1 ~ true
            // (a,b) = (true,false) ~ (1,0) 1*0 = 0 ~ true
            // (a,b) = (false,true) ~ (0,1) 0*1 = 0 ~ true
            // (a,b) = (false,false) ~ (0,0) 0*0 = 0 ~ false

        } else {
            String sum = a.toString() + b.toString();
            c = new StringCell(sum);
        }

        data[cx][cy] = c;
    }
}
