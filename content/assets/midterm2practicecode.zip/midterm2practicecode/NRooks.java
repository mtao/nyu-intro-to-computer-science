public class NRooks {
    public static void main(String[] args) {
        boolean[][] board = createBoard(8);
        set(board, 3,3);
        boolean seesNothing = visibility(board, 3,3);
        System.out.println(isValid(board)&& isComplete(board));
        
    }

    public static boolean[][] createBoard(int N) {
        return new boolean[N][N];
    }

    public static void set(boolean[][] board, int row, int col) {
        board[row][col] = true;
    }

    public static boolean visibility(boolean[][] board, int row, int col) {
        for(int r=  0; r < board.length; ++r) {
            if(r != row) {
            if(board[r][col]) {
                return false;
            }
            }
        }
        for(int c = 0; c < board[row].length; ++c) {
            if(c != col) {
                if(board[row][c]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean isComplete(boolean[][] board) {
        int target = board.length;

        int count = 0;
        for(boolean[] row: board) {
            for(boolean v: row) {
                if(v) {
                    count++;
                }
            }
        }
        return count == target;
    }

    public static boolean isValid(boolean[][] board) {
        for(int r = 0; r < board.length; ++r) {
            for(int c = 0; c < board[r].length; ++c) {
                if(board[r][c]) {
                    if(!visibility(board,r,c)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}
