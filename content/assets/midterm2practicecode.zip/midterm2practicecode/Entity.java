import java.util.ArrayList;

public class Entity {
    private String name;
    private BoundingBox boundingBox;

    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }

    // note that this doesn't do "deep cloning" which could cause problemms
    public void setBoundingBox(BoundingBox bbox) {
        this.boundingBox = bbox;
    }

    // note that this doesn't do "deep cloning" which could cause problemms
    public BoundingBox getBoundingBox() {
        return this.boundingBox;
    }

    private ArrayList<Entity> entities;

    public Entity(String name, BoundingBox bbox) {
        this.setName(name);
        this.setBoundingBox(bbox);

        // if the entities list hasn't been created so far it needs to be allocated
        if (entities == null) {
            entities = new ArrayList<>();
        }
        // add this entity to the list of entities
        entities.add(this);
    }

    // returns null if entity is not found - we will stop doing that after we learn about exceptions
    public Entity findEntity(String name) {
        for (Entity entity : entities) {
            if (entity.getName().equals(name)) {
                return entity;
            }
        }
        return null;
    }

    public Entity() {
        for (int j = 0;; ++j) {
            String name = "Entity " + j;
            // keep looking for new potential names
            if (findEntity(name) != null) {
                this.name = name;
                break;
            }
        }
        this.boundingBox = new BoundingBox();
    }

    public boolean collides(Entity other) {
        // note that the use of getBoundingBox is important for the followign questions (because
        // wedon't want to depend on the boundingBox member)
        return getBoundingBox().doesIntersect(other.getBoundingBox());
    }
}

// because boundingbox was using int we'll continue here, but it should have been double :(
class Sphere {
    private int radius;
    private Point center;

    public BoundingBox getBoundingBox() {
        BoundingBox bb = new BoundingBox();
        // the sphere/circle is bounded by a square, so we construct the corners
        bb.expand(new Point(center.x - radius, center.y - radius));
        bb.expand(new Point(center.x + radius, center.y + radius));
        return bb;
    }
}

class PointCloud {
    Point[] points;
    public BoundingBox getBoundingBox() {
        BoundingBox bb = new BoundingBox();
        // the sphere/circle is bounded by a square, so we construct the corners
        for (Point p : points) {
            bb.expand(p);
        }
        return bb;
    }
}

// we would have implicitly borrowed the getBoundingBox from teh PointCloud class
// one perspective is that a polygon is a collection of points ( a point cloud ) with a set of edges
// defined by the order of the points
class ConvexPolygon extends PointCloud {}
